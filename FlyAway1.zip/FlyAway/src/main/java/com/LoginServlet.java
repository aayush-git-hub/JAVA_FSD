package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	
		sendLoginForm(response, false);
	}

	private void sendLoginForm(HttpServletResponse response, boolean withErrorMessage) throws IOException {
		response.setContentType("text/HTML");
		PrintWriter out= response.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Login Page</TITLE");
		out.println("</HEAD>");
		out.println("<BODY>");
		
		if(withErrorMessage) {
			out.println("Login Failed. Please try again");
		}
		
		out.println("<BR>");
		out.println("<BR><H2>LOGIN PAGE</H2>");
		out.println("<BR>");
		out.println("<BR> <FORM METHOD=POST>");
		out.println("<TABLE>");
		out.println("<TR>");
		out.println("<TD>User Name: </TD>");
		out.println("<TD><INPUT TYPE=TEXT NAME=userName </TD>");
		out.println("</TR>");
		out.println("<TR>");
		out.println("<TD>Password: </TD>");
		out.println("<TD><INPUT TYPE=PASSWORD NAME=password </TD>");
		out.println("</TR>");
		out.println("<TR>");
		out.println("<TD ALIGN=RIGHT COLSPAN=2>");
		out.println("<INPUT TYPE=SUBMIT VALUE=Login/></TD>");
		out.println("</TR>");
		out.println("</TABLE>");
		out.println("</CENTER");
		out.println("</BODY>");
		out.println("</HTML>");
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		if(login(userName, password)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("PaymentServlet");
			dispatcher.forward(request, response);
		}else {
			sendLoginForm(response, true);
		}
	}

	private boolean login(String userName, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teksystems?useSSL=false", "root",  "asdf@12345");
			System.out.println("Connection successfull");
			Statement s=con.createStatement();
			String sql = "SELECT UserName FROM users WHERE UserName='" +userName+"' AND PASSWORD='" +password+ "'";
			ResultSet rs = s.executeQuery(sql);
			if(rs.next()) {
				rs.close();
				s.close();
				con.close();
				return true;
			} rs.close();
			s.close();
			con.close();
			
			
		} catch(ClassNotFoundException e) {
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
		
	}

}
