package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		try {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>PAYMENT GATEWAY</TITLE><BR>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println("<BR><H1>Dummy payment gateway--payment successfull<H1>");
		out.println("<br/><h2>Booking Details<h2><br/>");
		
		HttpSession session=request.getSession();
		String Sname=(String)session.getAttribute("Sname");
		String Dname=(String)session.getAttribute("Dname");
		Integer Seats=Integer.parseInt((String)session.getAttribute("Seats"));
		//Integer price=Integer.parseInt((String)session.getAttribute("price"));
		
		out.println("Source place:"+Sname);
		out.println("<BR>");
		out.println("Destination place:"+Dname);
		out.println("<BR>");
		out.println("No of passengers:"+Seats);
		out.println("<BR>");
		out.println("Total amount paid: 2892INR");
		out.println("<BR>");
		//out.println("Total ticket amount:"+(Seats*price));
		
		//out.println("Details"+Sname+"		"+Dname+"	"+Seats);

		//out.println("<HR COLOR="BLUE" SIZE="5"/>");
		//
        out.println("</BODY>");
        out.println("</HTML");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
        
	}

}
